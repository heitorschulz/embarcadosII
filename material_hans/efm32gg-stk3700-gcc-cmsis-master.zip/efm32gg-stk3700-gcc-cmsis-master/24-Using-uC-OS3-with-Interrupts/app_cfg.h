#ifndef APP_CFG_H
#define APP_CFG_H
/**
 *
 *
 */

#define  TASK0_PRIO       (10)
#define  TASK1_PRIO       (11)
#define  TASK2_PRIO       (12)
#define  TASKSTART_PRIO   (25)

#endif
